//welcome.js
;
(function() {


}).call(this);
